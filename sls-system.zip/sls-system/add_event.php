<?php
session_start();

define('USERNAME', 'admin'); 
define('PASSWORD_HASH', '$2y$10$wRiXkOhPwSNY3zLs6jqWQue1xWfkzkY0t/IpwQr1YKYKthqlJGgsW'); 


if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    
    
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"]) && $_POST["action"] == "add_event") {
        require 'config.php'; 

        $title = $_POST["title"];
        $event_date = $_POST["event_date"];
        $description = $_POST["description"];

       
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $image = $_FILES['image'];
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            if (in_array($image['type'], $allowed_types)) {
                $target_dir = 'uploads/';
                $target_file = $target_dir . basename($image['name']);

                
                if (file_exists($target_file)) {
                    $target_file = $target_dir . uniqid() . '-' . basename($image['name']);
                }

                
                if (move_uploaded_file($image['tmp_name'], $target_file)) {
                    
                    $sql = "INSERT INTO events (title, event_date, image, description) VALUES (?, ?, ?, ?)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$title, $event_date, $target_file, $description]);

                    echo "Wydarzenie dodane!";
                } else {
                    echo "Błąd podczas przesyłania pliku.";
                }
            } else {
                echo "Dozwolone są tylko pliki graficzne (JPEG, PNG, GIF).";
            }
        } else {
            echo "Proszę wybrać plik do przesyłania.";
        }
    }

    
    if (isset($_GET['delete_id'])) {
        require 'config.php';

        $event_id = $_GET['delete_id'];

        
        $sql = "SELECT image FROM events WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$event_id]);
        $event = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($event) {
            $image_path = $event['image'];

            
            $sql = "DELETE FROM events WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$event_id]);

            
            if (file_exists($image_path)) {
                unlink($image_path);
            }

            echo "Wydarzenie zostało usunięte!";
        } else {
            echo "Nie znaleziono wydarzenia.";
        }
    }

    
    if (isset($_POST['action']) && $_POST['action'] == 'edit_event') {
        require 'config.php';

        $event_id = $_POST['event_id'];
        $title = $_POST['title'];
        $description = $_POST['description'];

        
        $sql = "UPDATE events SET title = ?, description = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$title, $description, $event_id]);

        echo "Wydarzenie zostało zaktualizowane!";
    }

    
    if (isset($_POST['logout'])) {
        session_unset();  
        session_destroy();  
        header('Location: add_event.php'); 
        exit();
    }

} else {
    
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if ($username === USERNAME && password_verify($password, PASSWORD_HASH)) {
            $_SESSION['logged_in'] = true;
            header('Location: add_event.php'); 
            exit;
        } else {
            echo "Niepoprawna nazwa użytkownika lub hasło.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj wydarzenie</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }
        .container {
            display: flex;
            justify-content: space-between;
            gap: 20px; 
            margin-top: 20px;
            width: 100%;
        }
        .form-container {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 48%;
            
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        label {
            font-size: 14px;
            font-weight: bold;
            color: #555;
            margin-bottom: 5px;
            display: block;
        }
        input, textarea, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 14px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
        }
        button:hover {
            background-color: #45a049;
        }
        textarea {
            resize: vertical;
        }
        .logout-btn {
            background-color: #f44336;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
            margin-top: 20px;
            
        }
        .logout-btn:hover {
            background-color: #e53935;
        }
    </style>
</head>
<body>

<?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) { ?>
    
    <div class="form-container">
        <h1>Zaloguj się</h1>
        <form method="POST" action="add_event.php">
            <div class="form-group">
                <label for="username">Nazwa użytkownika:</label>
                <input type="text" name="username" id="username" required>
            </div>
            <div class="form-group">
                <label for="password">Hasło:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <button type="submit" name="login">Zaloguj się</button>
        </form>
    </div>
<?php } else { ?>
    
    <div class="container">
        <div class="form-container">
            <h1>Dodaj wydarzenie</h1>
            <form method="POST" action="add_event.php" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add_event">
                <div class="form-group">
                    <label for="title">Tytuł:</label>
                    <input type="text" name="title" id="title" required>
                </div>
                <div class="form-group">
                    <label for="event_date">Data:</label>
                    <input type="date" name="event_date" id="event_date" required>
                </div>
                <div class="form-group">
                    <label for="image">Obraz:</label>
                    <input type="file" name="image" id="image" required>
                </div>
                <div class="form-group">
                    <label for="description">Opis:</label>
                    <textarea name="description" id="description" required></textarea>
                </div>
                <button type="submit">Dodaj wydarzenie</button>
            </form>
        </div>

        
        <div class="form-container">
            <h1>Edytuj lub usuń wydarzenie</h1>
            <form method="POST" action="add_event.php">
                <div class="form-group">
                    <label for="event_select">Wybierz wydarzenie:</label>
                    <select name="event_id" id="event_select" required>
                        <?php
                        require 'config.php';
                        $sql = "SELECT * FROM events ORDER BY event_date DESC";
                        $stmt = $pdo->query($sql);
                        $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($events as $event) {
                            echo "<option value='" . $event['id'] . "'>" . htmlspecialchars($event['title']) . "</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="title">Tytuł:</label>
                    <input type="text" name="title" id="title" required>
                </div>
                <div class="form-group">
                    <label for="description">Opis:</label>
                    <textarea name="description" id="description" required></textarea>
                </div>
                <button type="submit" name="action" value="edit_event">Edytuj wydarzenie</button>
            </form>

            <form method="GET" action="add_event.php">
                <button type="submit" name="delete_id" value="<?php echo $event['id']; ?>" class="logout-btn">Usuń wydarzenie</button>
            </form>
        </div>
    </div>
    
    <form method="POST" action="add_event.php">
        <button type="submit" name="logout" class="logout-btn">Wyloguj się</button>
    </form>
<?php } ?>

</body>
</html>









