<?php
// sls/wyniki_podglad.php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/config.php';

// 1) Pobranie i walidacja hash
$hash = $_GET['hash'] ?? '';
if (!$hash) {
    die('Brak parametru turnieju.');
}

// 2) Pobranie danych turnieju wraz z flagą i datą udostępnienia
$stmt = $pdo->prepare("
  SELECT id, nazwa, `data`, results_shared, results_shared_at
    FROM turnieje
   WHERE hash = ?
");
$stmt->execute([$hash]);
$turniej = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$turniej) {
    die('Nie znaleziono turnieju.');
}
$turniej_id = (int)$turniej['id'];
$isShared   = (bool)$turniej['results_shared'];

// 3) Obsługa udostępniania / cofnięcia
if (isset($_SESSION['admin'], $_GET['share']) && !$isShared) {
    $pdo->prepare("UPDATE turnieje SET results_shared = 1, results_shared_at = NOW() WHERE id = ?")
        ->execute([$turniej_id]);
    header("Location: wyniki_podglad.php?hash=" . urlencode($hash));
    exit;
}
if (isset($_SESSION['admin'], $_GET['unshare']) && $isShared) {
    $pdo->prepare("UPDATE turnieje SET results_shared = 0, results_shared_at = NULL WHERE id = ?")
        ->execute([$turniej_id]);
    header("Location: wyniki_podglad.php?hash=" . urlencode($hash));
    exit;
}

// 4) Pobranie wyników wraz ze szkołą
$stmt2 = $pdo->prepare("
  SELECT 
    u.miejsce,
    u.imie,
    u.nazwisko,
    s.nazwa AS szkola,
    u.punkty,
    u.ranking
  FROM uczestnicy u
  JOIN szkoly s ON s.id = u.szkola_id
  WHERE u.turniej_id = ? AND u.zatwierdzony = 1
  ORDER BY u.miejsce ASC
");
$stmt2->execute([$turniej_id]);
$wyniki = $stmt2->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Wyniki – <?= htmlspecialchars($turniej['nazwa'], ENT_QUOTES) ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { margin:0; padding:20px; background:#f0f0f0; font-family:Lato,sans-serif; color:#131D58; }
    .header__logo-box { position:absolute; top:20px; left:20px; }
    .header__logo     { height:4rem; cursor:pointer; }
    .container        { max-width:900px; margin:100px auto; background:rgba(134,134,134,0.47); padding:30px; border-radius:8px; }
    h2 { text-align:center; font-size:2.5rem; margin-bottom:5px; }
    p.date { text-align:center; margin-bottom:20px; color:#131D58; }
    .actions { text-align:center; margin:20px 0; }
    .btn {
      display:inline-block; padding:10px 20px; margin:0 8px;
      background:#131D58; color:#fff; text-decoration:none;
      border-radius:5px; font-weight:bold; transition:background .3s;
    }
    .btn:hover { background:rgb(16,26,82); }
    .btn-unshare { background:#a00; }
    .btn-unshare:hover { background:#800; }
    .success-note {
      display:block; text-align:center; margin-bottom:20px;
      font-weight:bold; color:#2b572b;
    }
    table {
      width:100%; border-collapse:collapse; background:#fff;
      border-radius:5px; overflow:hidden;
    }
    thead { background:#131D58; }
    thead th {
      color:#fff; padding:12px; text-align:left; font-size:0.9rem;
    }
    tbody tr:nth-child(even) { background:#f4f4f4; }
    tbody tr:hover { background:#e0e0e0; }
    td { padding:10px; font-size:0.9rem; }
    .footer-actions { text-align:center; margin-top:30px; }
    @media print {
      .actions, .footer-actions { display:none; }
    }
  </style>
  <!-- do PDF generowanego po stronie klienta -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js"></script>
</head>
<body>

  <div class="header__logo-box">
    <a href="panel_turnieju.php?hash=<?= urlencode($hash) ?>">
      <img src="img/logo.avif" alt="Logo SLS" class="header__logo">
    </a>
  </div>

  <div class="container">
    <h2>Wyniki turnieju</h2>
    <p class="date"><?= date('d.m.Y', strtotime($turniej['data'])) ?></p>

    <div class="actions">
      <?php if (!$isShared): ?>
        <a href="?hash=<?= urlencode($hash) ?>&share=1" class="btn">Udostępnij wyniki</a>
      <?php else: ?>
        <span class="success-note">
          Wyniki udostępnione <?= date('d.m.Y H:i', strtotime($turniej['results_shared_at'])) ?>
        </span>
        <a href="?hash=<?= urlencode($hash) ?>&unshare=1" class="btn btn-unshare">
          Cofnij udostępnienie
        </a>
      <?php endif; ?>
      <a href="wpisz_wyniki.php?hash=<?= urlencode($hash) ?>" class="btn">Edytuj wyniki</a>
    </div>

    <table id="pdfTable">
      <thead>
        <tr>
          <th>Miejsce</th>
          <th>Imię</th>
          <th>Nazwisko</th>
          <th>Szkoła</th>
          <th>Punkty</th>
          <th>Ranking</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($wyniki)): ?>
          <tr>
            <td colspan="6" style="text-align:center; padding:20px;">Brak wyników.</td>
          </tr>
        <?php else: foreach ($wyniki as $w): ?>
          <tr>
            <td><?= htmlspecialchars($w['miejsce'], ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($w['imie'],    ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($w['nazwisko'],ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($w['szkola'],  ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($w['punkty'],  ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($w['ranking'], ENT_QUOTES) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>

    <div class="footer-actions">
      <a href="#" onclick="window.print();return false;" class="btn">Drukuj</a>
      <a href="#" id="exportPdfClient" class="btn">Eksportuj do PDF</a>
      <a href="panel_turnieju.php?hash=<?= urlencode($hash)?>" class="btn">← Wróć do panelu</a>
    </div>
  </div>

  <script>
    document.getElementById('exportPdfClient').addEventListener('click', () => {
      const el = document.getElementById('pdfTable');
      html2pdf().set({
        margin:       0.5,
        filename:     'wyniki_turnieju.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2 },
        jsPDF:        { unit: 'in', format: 'a4', orientation: 'landscape' }
      }).from(el).save();
    });
  </script>

</body>
</html>

