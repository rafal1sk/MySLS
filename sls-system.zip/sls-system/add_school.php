<?php
// sls/add_school.php

session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/config.php';

$blad    = '';
$sukces  = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nazwa = trim($_POST['nazwa'] ?? '');

    if ($nazwa === '') {
        $blad = 'Podaj nazwę szkoły.';
    } else {
        try {
            $ins = $pdo->prepare("
              INSERT INTO szkoly (nazwa, zatwierdzona)
              VALUES (?, 1)
            ");
            $ins->execute([$nazwa]);
            $sukces = true;
        } catch (Exception $e) {
            $blad = 'Błąd zapisu: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Dodaj szkołę | Panel Admina</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { background:#98989879; font-family:Lato,sans-serif; color:#131D58; margin:0; padding:20px; }
    .container { max-width:400px; margin:100px auto; background:rgba(134,134,134,0.47); padding:30px; border-radius:8px; box-shadow:0 0 10px rgba(0,0,0,0.2); }
    h2 { text-align:center; margin-bottom:20px; }
    label { display:block; margin-top:15px; font-weight:bold; color:#fff; }
    input { width:100%; padding:10px; margin-top:5px; border:none; border-radius:5px; background:rgba(151,151,151,0.47); color:#fff; }
    .btn { margin-top:20px; width:100%; padding:12px; background:#131D58; color:#fff; text-decoration:none; text-align:center; border:none; border-radius:5px; cursor:pointer; font-weight:bold; }
    .btn:hover { background:rgb(16,26,82); }
    .message { margin-top:15px; padding:10px; border-radius:5px; text-align:center; }
    .error   { background:#882828; color:#fff; }
    .success { background:#2b572b; color:#aef7ae; }
    .back { margin-top:10px; text-align:center; }
    .back a { color:#131D58; text-decoration:none; }
  </style>
</head>
<body>

  <div class="container">
    <h2>Dodaj nową szkołę</h2>

    <?php if ($blad): ?>
      <div class="message error"><?= $blad ?></div>
    <?php elseif ($sukces): ?>
      <div class="message success">Szkoła została dodana pomyślnie!</div>
    <?php endif; ?>

    <?php if (!$sukces): ?>
    <form method="POST">
      <label for="nazwa">Nazwa szkoły:</label>
      <input type="text" id="nazwa" name="nazwa" required placeholder="Pełna nazwa szkoły">

      <button type="submit" class="btn">Dodaj szkołę</button>
    </form>
    <?php endif; ?>

    <div class="back">
      <a href="panel.php">&larr; Powrót do panelu</a>
    </div>
  </div>

</body>
</html>
