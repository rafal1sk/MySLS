<?php
// sls/add_uczestnika.php

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once __DIR__ . '/config.php';

$msg = '';
$turnieje = $pdo->query("SELECT id,nazwa,`data` FROM turnieje ORDER BY `data` DESC")
                ->fetchAll(PDO::FETCH_ASSOC);
$szkoly   = $pdo->query("SELECT id,nazwa FROM szkoly WHERE zatwierdzona=1 ORDER BY nazwa")
                ->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['participants'])) {
    $turniej_id = (int)($_POST['turniej_id'] ?? 0);
    $errors = [];
    if (!$turniej_id) {
        $errors[] = 'Nie wybrano turnieju.';
    } else {
        $pdo->beginTransaction();
        $ins = $pdo->prepare("
          INSERT INTO uczestnicy
            (imie,nazwisko,email,klasa,szkola_id,turniej_id,zatwierdzony)
          VALUES (?, ?, ?, ?, ?, ?, 0)
        ");
        foreach ($_POST['participants'] as $i => $p) {
            $imie     = mb_convert_case(mb_strtolower(trim($p['imie']),'UTF-8'),
                                        MB_CASE_TITLE,'UTF-8');
            $nazwisko = mb_convert_case(mb_strtolower(trim($p['nazwisko']),'UTF-8'),
                                        MB_CASE_TITLE,'UTF-8');
            $email    = trim($p['email']);
            $klasa    = trim($p['klasa']);
            $szkola_id= (int)$p['szkola_id'];
            if (!$imie||!$nazwisko||!filter_var($email,FILTER_VALIDATE_EMAIL)
                ||!$klasa||!$szkola_id) {
                $errors[] = "Wiersz #".($i+1)." zawiera niepełne lub niepoprawne dane.";
                continue;
            }
            $ins->execute([$imie,$nazwisko,$email,$klasa,$szkola_id,$turniej_id]);
        }
        if (empty($errors)) {
            $pdo->commit();
            $msg = "<div class='success'>Wstawiono wszystkich uczestników do zatwierdzenia.</div>";
        } else {
            $pdo->rollBack();
            $msg = "<div class='error'>".implode('<br>',$errors)."</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Dodaj uczestników – Panel Admina</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body{margin:0;padding:20px;background:#98989879;font-family:Lato,sans-serif;color:#131D58;}
    .container{max-width:960px;margin:40px auto;background:rgba(134,134,134,0.47);
      padding:30px;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.2);}
    h2{text-align:center;margin-bottom:20px;}
    label{display:block;margin-top:15px;font-weight:bold;color:#fff;}
    select,input{width:100%;padding:10px;margin-top:5px;border:none;
      border-radius:5px;background:rgba(151,151,151,0.47);color:#fff;}
    table{width:100%;border-collapse:collapse;margin-top:20px;background:#fff;
      border-radius:5px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.1);}
    thead{background:#131D58;}thead th{color:#fff;padding:10px;text-align:left;}
    tbody tr:nth-child(even){background:#f4f4f4;}tbody td{padding:8px;}
    input.row-input,select.row-select{background:#fff;color:#000;width:100%;border:1px solid #ccc;}
    .btn{display:inline-block;padding:10px 20px;background:#131D58;color:#fff;
      text-decoration:none;border:none;border-radius:5px;cursor:pointer;margin:10px 5px;
      font-weight:bold;transition:background .3s;}
    .btn:hover{background:rgb(16,26,82);}
    .success,.error{margin:15px 0;padding:12px;border-radius:5px;text-align:center;}
    .success{background:#2b572b;color:#aef7ae;} .error{background:#882828;color:#fff;}
    .actions{text-align:center;margin-top:20px;}
  </style>
</head>
<body>
<div class="container">
  <h2>Dodaj uczestników</h2>
  <?= $msg ?>

  <!-- Krok 1: wybierz turniej -->
  <div id="step1">
    <label for="turniej">Wybierz turniej:</label>
    <select id="turniej">
      <option value="">-- wybierz --</option>
      <?php foreach($turnieje as $t): ?>
        <option value="<?= $t['id'] ?>">
          <?= htmlspecialchars($t['nazwa'],ENT_QUOTES) ?>
          (<?= date('d.m.Y',strtotime($t['data'])) ?>)
        </option>
      <?php endforeach; ?>
    </select>
    <div class="actions">
      <button id="confirmTurniej" class="btn" disabled>Potwierdź turniej</button>
    </div>
  </div>

  <!-- Krok 2: tabela uczestników -->
  <form method="POST" id="formParticipants" style="display:none;">
    <input type="hidden" name="turniej_id" id="form_turniej_id">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Szkoła</th>
          <th>Imię</th>
          <th>Nazwisko</th>
          <th>E-mail</th>
          <th>Klasa</th>
          <th>Usuń</th>
        </tr>
      </thead>
      <tbody id="rows">
        <!-- wiersze dodawane JS -->
      </tbody>
    </table>
    <div class="actions">
      <button type="button" id="addRow" class="btn">Dodaj wiersz</button>
      <button type="submit" class="btn">Zapisz wszystkich</button>
    </div>
  </form>
</div>

<script>
const szkolaOptions = `<?php foreach($szkoly as $s){
  echo "<option value='{$s['id']}'>".addslashes($s['nazwa'])."</option>";
} ?>`;

let rowCount = 0;
const rows = document.getElementById('rows');
document.getElementById('turniej').addEventListener('change',function(){
  document.getElementById('confirmTurniej').disabled = !this.value;
});
document.getElementById('confirmTurniej').addEventListener('click',()=>{
  const t = document.getElementById('turniej').value;
  if(!t) return;
  document.getElementById('form_turniej_id').value = t;
  document.getElementById('step1').style.display = 'none';
  document.getElementById('formParticipants').style.display = 'block';
  addRow();
});

function addRow(){
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td>${++rowCount}</td>
    <td>
      <select name="participants[${rowCount}][szkola_id]" class="row-select" required>
        <option value="">– wybierz –</option>${szkolaOptions}
      </select>
    </td>
    <td><input type="text" name="participants[${rowCount}][imie]" class="row-input" required></td>
    <td><input type="text" name="participants[${rowCount}][nazwisko]" class="row-input" required></td>
    <td><input type="email" name="participants[${rowCount}][email]" class="row-input" required></td>
    <td><input type="text" name="participants[${rowCount}][klasa]" class="row-input" required></td>
    <td><button type="button" class="btn" onclick="this.closest('tr').remove()">×</button></td>
  `;
  rows.appendChild(tr);
}
document.getElementById('addRow').addEventListener('click',addRow);
</script>
</body>
</html>

