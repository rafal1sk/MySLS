<?php
include('config.php');

$komunikat = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['zatwierdz_id'])) {
    $id = $_POST['zatwierdz_id'];
    $stmt = $pdo->prepare("UPDATE szkoly SET zatwierdzona = 1 WHERE id = ?");
    $stmt->execute([$id]);
    $komunikat = "<div class='success'>Szkoła zatwierdzona!</div>";
}

$szkoly = $pdo->query("SELECT * FROM szkoly WHERE zatwierdzona = 0")->fetchAll();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zatwierdź szkoły</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: 'Lato', sans-serif;
            background-color: #98989879;
            color: #131D58;
            padding: 20px;
            margin: 0;
        }
        .header__logo-box {
            position: absolute;
            top: 3%;
            left: 3%;
        }
        .header__logo {
            height: 6rem;
            filter: drop-shadow(0 2rem 4rem rgba(0, 0, 0, 0.9));
        }
        h2 {
            text-align: center;
            font-size: 3rem;
        }
        .success {
            background: #2b572b;
            color: #aef7ae;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            max-width: 600px;
            margin: 20px auto;
            text-align: center;
        }
        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background: rgba(134, 134, 134, 0.47);
            border-radius: 8px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }
        th {
            background-color: #131D58;
            color: #fff;
        }
        form {
            display: inline;
        }
        button {
            background-color: #131D58;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #101a52;
        }
    </style>
</head>
<body>

<div class="header__logo-box">
    
        <a href="panel.php">
            <img src="img/logo.avif" alt="Logo" class="header__logo" style="cursor:pointer;">
        </a>
    
</div>


<h2>Zatwierdzanie szkół</h2>

<?= $komunikat ?>

<?php if (count($szkoly) === 0): ?>
    <p style="text-align:center;">Brak szkół do zatwierdzenia.</p>
<?php else: ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Nazwa szkoły</th>
            <th>Akcja</th>
        </tr>
        <?php foreach ($szkoly as $s): ?>
            <tr>
                <td><?= $s['id'] ?></td>
                <td><?= htmlspecialchars($s['nazwa']) ?></td>
                <td>
                    <form method="POST">
                        <input type="hidden" name="zatwierdz_id" value="<?= $s['id'] ?>">
                        <button type="submit">Zatwierdź</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

</body>
</html>

