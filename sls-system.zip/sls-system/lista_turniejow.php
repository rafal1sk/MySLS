<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once __DIR__ . '/config.php';

$stmt = $pdo->query("SELECT nazwa, `data`, hash FROM turnieje ORDER BY `data` DESC");
$turnieje = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pl">
<head><meta charset="UTF-8"><title>Lista turniejów</title>
  <style>
    /* Twój CSS… */
    <style>
    body {
      background-color: #98989879;
      font-family: 'League Gothic', sans-serif;
      color: #131D58;
      margin: 0;
      padding: 20px;
    }
    .header__logo-box {
      position: absolute;
      top: 3%;
      left: 3%;
      z-index: 10;
    }
    .header__logo {
      height: 6rem;
      filter: drop-shadow(0 2rem 4rem rgba(0,0,0,0.9));
      cursor: pointer;
    }
    .container {
      max-width: 800px;
      margin: 100px auto;
      background-color: rgba(134,134,134,0.47);
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(134,134,134,0.47);
    }

    /* NAGŁÓWEK */
    h2 {
      text-align: center;
      font-size: 3rem;
      margin-bottom: 20px;
    }

    /* TABELA */
    table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
      border-radius: 5px;
      overflow: hidden;
    }
    thead {
      background-color: #131D58;
    }
    thead th {
      color: #fff;
      font-weight: normal;
      text-transform: uppercase;
      font-size: 0.9rem;
      padding: 12px;
      text-align: left;
    }
    tbody tr:nth-child(even) {
      background-color: #f0f0f0;
    }
    tbody tr:hover {
      background-color: #e0e0e0;
    }
    tbody td {
      padding: 12px;
      font-size: 0.9rem;
      color: #131D58;
    }

    /* PRZYCISKI */
    .btn {
      display: inline-block;
      padding: 8px 14px;
      margin: 0;
      background-color: #131D58;
      color: #fff;
      text-decoration: none;
      border-radius: 5px;
      font-size: 0.85rem;
      transition: background 0.3s ease;
    }
    .btn:hover {
      background-color: rgb(16,26,82);
    }
</style>

  </style>
</head>
<body>
    <div class="header__logo-box">
        <a href="panel.php">
      <img src="img/logo.avif" alt="Logo" class="header__logo">
    </a>
  </div>
  <h2>Lista turniejów</h2>
  <table>
    <tr><th>Nazwa</th><th>Data</th><th>Opcje</th></tr>
    <?php foreach ($turnieje as $t): ?>
    <tr>
      <td><?= htmlspecialchars($t['nazwa']) ?></td>
      <td><?= date('d.m.Y', strtotime($t['data'])) ?></td>
      <td>
        <a href="panel_turnieju.php?hash=<?= urlencode($t['hash']) ?>" class="btn">Opcje</a>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
</body>
</html>




