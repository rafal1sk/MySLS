<?php
// sls/usun_turniej.php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/config.php';

try {
    // 1) Walidujemy parametr hash
    $hash = $_GET['hash'] ?? '';
    if (!$hash) {
        throw new Exception("Brak parametru turnieju.");
    }

    // 2) Pobieramy ID i nazwę turnieju
    $stmt = $pdo->prepare("SELECT id, nazwa FROM turnieje WHERE hash = ?");
    $stmt->execute([$hash]);
    $turniej = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$turniej) {
        throw new Exception("Nie znaleziono turnieju.");
    }

    // 3) Usuwamy uczestników i sam turniej
    $pdo->beginTransaction();

    // usuń zgłoszenia uczniów
    $delU = $pdo->prepare("DELETE FROM uczestnicy WHERE turniej_id = ?");
    $delU->execute([$turniej['id']]);

    // jeżeli będziesz miał tabelę events powiązaną z turniejem:
    // odkomentuj i podmień 'XXX' na właściwą kolumnę (np. hash lub event_id):
    //
    // $delE = $pdo->prepare("DELETE FROM events WHERE XXX = ?");
    // $delE->execute([$turniej['id']]);

    // wreszcie usuń sam turniej
    $delT = $pdo->prepare("DELETE FROM turnieje WHERE id = ?");
    $delT->execute([$turniej['id']]);

    $pdo->commit();

    $_SESSION['message'] = "Turniej „{$turniej['nazwa']}” został usunięty.";
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['error'] = "Błąd podczas usuwania: " . $e->getMessage();
}

// 4) Przekierowujemy z powrotem na listę
header('Location: lista_turniejow.php');
exit;
