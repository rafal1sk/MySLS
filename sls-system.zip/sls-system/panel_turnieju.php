<?php
// sls/panel_turnieju.php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
require_once __DIR__ . '/config.php';

// 1) Pobierz hash i dane turnieju (w tym flagę override_registration)
$hash = $_GET['hash'] ?? '';
if (!$hash) {
    die('Brak parametru turnieju!');
}
$stmt = $pdo->prepare("SELECT id, nazwa, `data`, override_registration FROM turnieje WHERE hash = ?");
$stmt->execute([$hash]);
$turniej = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$turniej) {
    die('Nie znaleziono takiego turnieju!');
}
$turniej_id = (int)$turniej['id'];

// 2) Obsługa toggle override_registration
if (isset($_GET['toggle'])) {
    $new = $turniej['override_registration'] ? 0 : 1;
    $upd = $pdo->prepare("UPDATE turnieje SET override_registration = ? WHERE id = ?");
    $upd->execute([$new, $turniej_id]);
    header("Location: panel_turnieju.php?hash=" . urlencode($hash));
    exit;
}

// 3) Generujemy URL rejestracji
$proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http';
$base    = "{$proto}://{$_SERVER['HTTP_HOST']}" . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$regLink = "{$base}/rejestracja.php?hash=" . urlencode($hash);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Panel turnieju</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { background:#98989879; font-family:'League Gothic',sans-serif; color:#131D58; margin:0;padding:20px; }
    .header__logo-box { position:absolute; top:3%; left:3%; }
    .header__logo { height:6rem; filter:drop-shadow(0 2rem 4rem rgba(0,0,0,0.9)); cursor:pointer; }
    .container { max-width:600px; margin:100px auto; background:rgba(134,134,134,0.47); padding:30px; border-radius:8px; box-shadow:0 0 10px rgba(134,134,134,0.47); text-align:center; }
    h2 { font-size:3rem; margin-bottom:10px; }
    p { font-size:1.1rem; margin-bottom:20px; }
    a.btn { display:block; margin:10px auto; padding:12px; background:#131D58; color:#fff; text-decoration:none; border-radius:5px; font-weight:bold; transition:background .3s; max-width:80%; }
    a.btn:hover { background:rgb(16,26,82); }
    #reg-link-container { display:none; margin-top:15px; }
    #reg-link-container input { width:100%; padding:10px; border:none; border-radius:5px; background:#fff; box-shadow:inset 0 1px 3px rgba(0,0,0,0.1); cursor:text; }
    #reg-link-container input:focus { outline:2px solid #131D58; }
    .status { margin:15px 0; font-size:1rem; }
    .status span { font-weight:bold; color:#fff; padding:4px 8px; border-radius:4px; }
    .status .on { background:#2b572b; }
    .status .off { background:#882828; }
  </style>
  <script>
    function toggleRegLink() {
      const c = document.getElementById('reg-link-container');
      c.style.display = (c.style.display === 'block') ? 'none' : 'block';
    }
  </script>
</head>
<body>

  <div class="header__logo-box">
    <a href="panel.php"><img src="img/logo.avif" alt="Logo" class="header__logo"></a>
  </div>

  <div class="container">
    <h2>Panel turnieju</h2>
    <p>
      <strong><?= htmlspecialchars($turniej['nazwa'], ENT_QUOTES) ?></strong><br>
      (<?= date('d.m.Y', strtotime($turniej['data'])) ?>)
    </p>
    <a href="zatwierdz_ucznia.php?hash=<?= urlencode($hash) ?>"     class="btn">Zatwierdź uczniów</a>
    <a href="wpisz_wyniki.php?hash=<?= urlencode($hash) ?>"         class="btn">Wpisz wyniki</a>
    <a href="lista_uczestnikow.php?hash=<?= urlencode($hash) ?>"    class="btn">Zobacz listę</a>
    <a href="wyniki_podglad.php?hash=<?= urlencode($hash) ?>"       class="btn">Zobacz wyniki</a>
    <a href="usun_turniej.php?hash=<?= urlencode($hash) ?>"         class="btn" onclick="return confirm('Na pewno usunąć ten turniej?');">
      Usuń turniej
    </a>
    
   <a href="#" class="btn" onclick="toggleRegLink(); return false;">Pokaż/Ukryj link rejestracji</a>
    <div id="reg-link-container">
      <input type="text" value="<?= htmlspecialchars($regLink, ENT_QUOTES) ?>" readonly onclick="this.select()">
    </div>
    <a href="panel_turnieju.php?hash=<?= urlencode($hash) ?>&toggle=1"
       class="btn">
      <?php if ($turniej['override_registration']): ?>
        Wyłącz rejestrację po terminie
      <?php else: ?>
        Włącz rejestrację po terminie
      <?php endif; ?>
    </a>
    <div class="status">
      Rejestracja po terminie:
      <?php if ($turniej['override_registration']): ?>
        <span class="on">WŁĄCZONA</span>
      <?php else: ?>
        <span class="off">WYŁĄCZONA</span>
      <?php endif; ?>
    </div>

    <a href="lista_turniejow.php" class="btn">← Wróć do listy</a>
  </div>

</body>
</html>



