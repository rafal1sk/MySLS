<?php
// sls/lista_uczestnikow.php

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__.'/config.php';

// 1) Pobranie hash
$hash = $_GET['hash'] ?? '';
if (!$hash) {
    die('Brak parametru turnieju.');
}

// 2) Pobranie danych turnieju
$stmt = $pdo->prepare("SELECT id,nazwa,`data` FROM turnieje WHERE hash = ?");
$stmt->execute([$hash]);
$turniej = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$turniej) {
    die('Nie znaleziono turnieju.');
}
$turniej_id = (int)$turniej['id'];

// 3) Pobranie uczestników
$stmt2 = $pdo->prepare("
  SELECT u.imie, u.nazwisko, u.klasa, s.nazwa AS szkola
  FROM uczestnicy u
  JOIN szkoly s ON s.id = u.szkola_id
  WHERE u.turniej_id = ? AND u.zatwierdzony = 1
  ORDER BY u.id ASC
");
$stmt2->execute([$turniej_id]);
$uczestnicy = $stmt2->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Lista uczestników – <?= htmlspecialchars($turniej['nazwa'],ENT_QUOTES) ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { margin:0; padding:20px; background:#f0f0f0; font-family:Lato,sans-serif; color:#131D58; }
    .header__logo-box { position:absolute; top:20px; left:20px; }
    .header__logo     { height:4rem; cursor:pointer; }
    .container        { max-width:900px; margin:100px auto 40px; background:rgba(134,134,134,0.47); padding:30px; border-radius:8px; }
    h2                { text-align:center; font-size:2.5rem; margin-bottom:5px; }
    p.date            { text-align:center; margin-bottom:30px; color:#131D58; }
    table             { width:100%; border-collapse:collapse; background:#fff; border-radius:5px; overflow:hidden; }
    thead             { background:#131D58; }
    thead th          { color:#fff; padding:12px; text-align:left; font-weight:normal; }
    tbody tr:nth-child(even) { background:#f4f4f4; }
    tbody tr:hover    { background:#e0e0e0; }
    td                { padding:10px; font-size:0.9rem; }
    .footer-actions   { text-align:center; margin-top:30px; }
    .btn              { display:inline-block; padding:8px 16px; background:#131D58; color:#fff; text-decoration:none; border-radius:4px; transition:background .3s; margin:0 8px; }
    .btn:hover        { background:rgb(16,26,82); }
    @media print { .footer-actions { display:none; } }
  </style>
  <!-- klient-side PDF -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js"></script>
</head>
<body>

  <div class="header__logo-box">
    <a href="panel_turnieju.php?hash=<?= urlencode($hash) ?>">
      <img src="img/logo.avif" alt="Logo" class="header__logo">
    </a>
  </div>

  <div class="container">
    <h2>Lista uczestników</h2>
    <p class="date"><?= date('d.m.Y', strtotime($turniej['data'])) ?></p>

    <table id="pdfTable">
      <thead>
        <tr>
          <th>Imię</th>
          <th>Nazwisko</th>
          <th>Klasa</th>
          <th>Szkoła</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($uczestnicy)): ?>
          <tr><td colspan="4" style="text-align:center; padding:20px;">Brak uczestników.</td></tr>
        <?php else: foreach ($uczestnicy as $u): ?>
          <tr>
            <td><?= htmlspecialchars($u['imie']     ?? '', ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($u['nazwisko'] ?? '', ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($u['klasa']    ?? '', ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($u['szkola']   ?? '', ENT_QUOTES) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>

    <div class="footer-actions">
      <a href="#" onclick="window.print();return false;" class="btn">Drukuj</a>
      <button id="exportPdfClient" class="btn">Eksportuj do PDF</button>
      <a href="panel_turnieju.php?hash=<?= urlencode($hash)?>" class="btn">← Wróć do panelu</a>
    </div>
  </div>

  <script>
    document.getElementById('exportPdfClient').addEventListener('click', () => {
      const element = document.getElementById('pdfTable');
      const opt = {
        margin:       0.5,
        filename:     'lista_uczestnikow.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2 },
        jsPDF:        { unit: 'in', format: 'a4', orientation: 'landscape' }
      };
      html2pdf().set(opt).from(element).save();
    });
  </script>

</body>
</html>

