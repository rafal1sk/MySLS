<?php
// sls/wpisz_wyniki.php

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/config.php';

// 1) Pobranie i walidacja hash
$hash = $_GET['hash'] ?? '';
if (!$hash) {
    die('<div class="error">Błąd: brak parametru turnieju.</div>');
}

// 2) Pobranie danych turnieju
$stmt = $pdo->prepare("SELECT id,nazwa,`data` FROM turnieje WHERE hash = ?");
$stmt->execute([$hash]);
$turniej = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$turniej) {
    die('<div class="error">Błąd: nie znaleziono turnieju.</div>');
}
$turniej_id = (int)$turniej['id'];

$msg = '';

// 3) Obsługa POST: walidacja + zapis w transakcji
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];

    // miejsce: 1–999 (1–3 cyfry)
    foreach ($_POST['miejsce'] as $uid => $m) {
        if (!preg_match('/^[0-9]{1,3}$/', $m) || (int)$m < 1) {
            $errors[] = "Nieprawidłowe miejsce dla ID $uid.";
        }
    }
    // punkty: 0–99 (1–2 cyfry)
    foreach ($_POST['punkty'] as $uid => $p) {
        if (!preg_match('/^[0-9]{1,2}$/', $p)) {
            $errors[] = "Nieprawidłowe punkty dla ID $uid.";
        }
    }
    // ranking: dokładnie 4 cyfry
    foreach ($_POST['ranking'] as $uid => $r) {
        if (!preg_match('/^[0-9]{4}$/', $r)) {
            $errors[] = "Ranking musi być 4-cyfrową liczbą dla ID $uid.";
        }
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            $upd = $pdo->prepare("
                UPDATE uczestnicy
                   SET miejsce = ?, punkty = ?, ranking = ?
                 WHERE id = ? AND turniej_id = ?
            ");
            foreach ($_POST['miejsce'] as $uid => $miejsce) {
                $upd->execute([
                    (int)$miejsce,
                    (int)$_POST['punkty'][$uid],
                    (int)$_POST['ranking'][$uid],
                    (int)$uid,
                    $turniej_id
                ]);
            }
            $pdo->commit();
            $msg = "<div class='success'>Wyniki zapisane pomyślnie.</div>";
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $msg = "<div class='error'>Błąd podczas zapisu:<br>"
                 . htmlspecialchars($e->getMessage(), ENT_QUOTES)
                 . "</div>";
        }
    } else {
        $msg = "<div class='error'>" . implode('<br>', $errors) . "</div>";
    }
}

// 4) Pobranie uczestników
$stmt2 = $pdo->prepare("
    SELECT id, imie, nazwisko, klasa, miejsce, punkty, ranking
    FROM uczestnicy
    WHERE turniej_id = ? AND zatwierdzony = 1
    ORDER BY id
");
$stmt2->execute([$turniej_id]);
$uczestnicy = $stmt2->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Wpisz wyniki – <?= htmlspecialchars($turniej['nazwa'], ENT_QUOTES) ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { margin:0; padding:20px; background:#98989879; font-family:Lato,sans-serif; color:#131D58; }
    .header__logo-box { position:absolute; top:3%; left:3%; }
    .header__logo { height:6rem; cursor:pointer; }
    .container {
      max-width:900px; margin:100px auto; padding:30px;
      background:rgba(134,134,134,0.47); border-radius:8px;
      box-shadow:0 0 10px rgba(134,134,134,0.47);
    }
    h2 { text-align:center; font-size:2.8rem; margin-bottom:5px; }
    p.date { text-align:center; margin-bottom:20px; }
    .success, .error {
      max-width:800px; margin:10px auto; padding:12px;
      border-radius:5px; text-align:center;
    }
    .success { background:#2b572b; color:#aef7ae; }
    .error   { background:#882828; color:#fff; }
    table {
      width:100%; border-collapse:collapse; background:#fff;
      border-radius:5px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.1);
    }
    thead { background:#131D58; }
    thead th {
      color:#fff; padding:12px; text-align:left; font-size:0.9rem;
    }
    tbody tr:nth-child(even) { background:#f4f4f4; }
    tbody tr:hover { background:#e0e0e0; }
    td { padding:10px; font-size:0.9rem; vertical-align:middle; }

    /* pola wejściowe */
    input.miejsce,
    input.punkty,
    input.ranking {
      font-size:0.9rem; padding:4px; text-align:center;
    }
    /* miejsce: max 3 cyfry */
    input.miejsce {
      width:4rem; maxlength:3; pattern="[0-9]{1,3}";
      inputmode="numeric";
      oninput="this.value=this.value.replace(/\D/g,'').slice(0,3)";
    }
    /* punkty: max 2 cyfry */
    input.punkty {
      width:3rem; maxlength:2; pattern="[0-9]{1,2}";
      inputmode="numeric";
      oninput="this.value=this.value.replace(/\D/g,'').slice(0,2)";
    }
    /* ranking: max 4 cyfry */
    input.ranking {
      width:5rem; maxlength:4; pattern="[0-9]{4}";
      inputmode="numeric";
      oninput="this.value=this.value.replace(/\D/g,'').slice(0,4)";
    }

    button.btn {
      display:inline-block; padding:8px 16px; background:#131D58;
      color:#fff; border:none; border-radius:4px; margin:10px 4px;
      cursor:pointer; font-size:0.9rem; transition:background .3s;
    }
    button.btn:hover { background:rgb(16,26,82); }
    .back-btn { text-align:center; margin-top:20px; }

    @media (max-width:600px) {
      table, thead, tbody, th, td, tr { display:block; }
      thead tr { position:absolute; top:-9999px; left:-9999px; }
      tr { margin-bottom:10px; }
      td {
        border:none; position:relative; padding-left:50%;
      }
      td:before {
        position:absolute; top:10px; left:10px;
        width:45%; white-space:nowrap; font-weight:bold;
      }
      td:nth-of-type(1):before { content:"ID"; }
      td:nth-of-type(2):before { content:"Imię"; }
      td:nth-of-type(3):before { content:"Nazwisko"; }
      td:nth-of-type(4):before { content:"Klasa"; }
      td:nth-of-type(5):before { content:"Miejsce"; }
      td:nth-of-type(6):before { content:"Punkty"; }
      td:nth-of-type(7):before { content:"Ranking"; }
    }
  </style>
</head>
<body>

  <div class="header__logo-box">
    <a href="panel_turnieju.php?hash=<?= urlencode($hash) ?>">
      <img src="img/logo.avif" alt="Logo" class="header__logo">
    </a>
  </div>

  <div class="container">
    <h2>Wpisz wyniki</h2>
    <p class="date"><?= date('d.m.Y', strtotime($turniej['data'])) ?></p>

    <?= $msg ?>

    <?php if ($uczestnicy): ?>
      <form method="POST" action="?hash=<?= urlencode($hash) ?>">
        <table>
          <thead>
            <tr>
              <th>ID</th><th>Imię</th><th>Nazwisko</th><th>Klasa</th>
              <th>Miejsce</th><th>Punkty</th><th>Ranking</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($uczestnicy as $u): ?>
              <tr>
                <td><?= $u['id'] ?></td>
                <td><?= htmlspecialchars($u['imie'], ENT_QUOTES) ?></td>
                <td><?= htmlspecialchars($u['nazwisko'], ENT_QUOTES) ?></td>
                <td><?= htmlspecialchars($u['klasa'], ENT_QUOTES) ?></td>
                <td>
  <!-- Miejsce: maks. 3 cyfry -->
  <input type="text"
         class="miejsce"
         name="miejsce[<?= $u['id'] ?>]"
         value="<?= $u['miejsce'] ?? '' ?>"
         pattern="[0-9]{1,3}"
         maxlength="3"
         inputmode="numeric"
         oninput="this.value = this.value.replace(/\D/g,'').slice(0,3)"
         required>
</td>
<td>
  <!-- Punkty: maks. 2 cyfry -->
  <input type="text"
         class="punkty"
         name="punkty[<?= $u['id'] ?>]"
         value="<?= $u['punkty'] ?? '' ?>"
         pattern="[0-9]{1,2}"
         maxlength="2"
         inputmode="numeric"
         oninput="this.value = this.value.replace(/\D/g,'').slice(0,2)"
         required>
</td>
<td>
  <!-- Ranking: maks. 4 cyfry -->
  <input type="text"
         class="ranking"
         name="ranking[<?= $u['id'] ?>]"
         value="<?= $u['ranking'] ?? '' ?>"
         pattern="[0-9]{4}"
         maxlength="4"
         inputmode="numeric"
         oninput="this.value = this.value.replace(/\D/g,'').slice(0,4)"
         required>
</td>

              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <div style="text-align:center;">
          <button type="submit" class="btn">Zapisz wyniki</button>
        </div>
      </form>
    <?php else: ?>
      <p style="text-align:center; padding:20px;">Brak zatwierdzonych uczestników.</p>
    <?php endif; ?>

    <div class="back-btn">
      <button onclick="window.location='panel_turnieju.php?hash=<?= urlencode($hash) ?>';" class="btn">
        ← Powrót do panelu
      </button>
    </div>
  </div>

</body>
</html>
