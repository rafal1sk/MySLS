<?php
// sls/panel.php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Panel główny</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preload" href="https://fonts.googleapis.com/css2?...wap" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <style>
        body {
            background-color: #98989879;
            font-family: 'League Gothic', sans-serif;
            color: #131D58;
            margin: 0;
            padding: 20px;
        }
        .header__logo-box {
            position: absolute;
            top: 3%;
            left: 3%;
        }
        .header__logo {
            height: 6rem;
            filter: drop-shadow(0 2rem 4rem rgba(0, 0, 0, 0.9));
            cursor: pointer;
        }
        .container {
            max-width: 600px;
            margin: 100px auto;
            background-color: rgba(134, 134, 134, 0.47);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(134, 134, 134, 0.47);
            text-align: center;
        }
        h2 {
            font-size: 3rem;
        }
        a.btn {
            display: block;
            margin: 15px 0;
            padding: 12px;
            background-color: #131D58;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.3s ease;
        }
        a.btn:hover {
            background-color: rgb(16, 26, 82);
        }
    </style>
</head>
<body>
    <div class="header__logo-box">
        <a href="panel.php"><img src="img/logo.avif" alt="Logo" class="header__logo"></a>
    </div>
    <div class="container">
        <h2>Panel administratora</h2>
        <!-- Nowy przycisk do tworzenia turnieju -->
        <a href="tworz_turniej.php" class="btn">Utwórz turniej</a>
        <a href="lista_turniejow.php" class="btn">Lista turniejow</a>
        <a href="add_school.php" class="btn">Dodaj szkołę</a>
        <a href="add_uczestnika.php" class="btn">Dodaj uczestnika</a>
        <a href="add_event.php" class="btn">Dodaj wydarzenie</a>
        <a href="logout_a.php" class="btn">Wyloguj się</a>
    </div>
</body>
</html>

