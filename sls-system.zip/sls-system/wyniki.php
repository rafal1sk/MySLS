<?php
// sls/wyniki.php

require_once __DIR__ . '/config.php';

// AJAX: zwraca tabelę wyników dla danego turnieju
if (isset($_GET['ajax'], $_GET['hash']) && $_GET['ajax'] === '1') {
    $hash = $_GET['hash'];
    // Pobierz id turnieju
    $stmt = $pdo->prepare("SELECT id, nazwa, `data` FROM turnieje WHERE hash = ?");
    $stmt->execute([$hash]);
    $t = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$t) {
        echo json_encode(['html' => '<p style="padding:20px; text-align:center;">Błąd: nie znaleziono turnieju.</p>']);
        exit;
    }
    // Pobierz wyniki z nazwą szkoły
    $stmt2 = $pdo->prepare("
      SELECT u.miejsce, u.imie, u.nazwisko, s.nazwa AS szkola, u.punkty, u.ranking
      FROM uczestnicy u
      JOIN szkoly s ON s.id = u.szkola_id
      WHERE u.turniej_id = ?
        AND u.zatwierdzony = 1
      ORDER BY u.miejsce ASC
    ");
    $stmt2->execute([$t['id']]);
    $wyniki = $stmt2->fetchAll(PDO::FETCH_ASSOC);

    // Buduj tabelę
    $html  = '<h3 style="margin-top:0;">' . htmlspecialchars($t['nazwa'], ENT_QUOTES) 
           . ' (' . date('d.m.Y', strtotime($t['data'])) . ')</h3>';
    $html .= '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;margin-top:10px;">';
    $html .= '<thead><tr style="background:#131D58;color:#fff;">'
           . '<th style="padding:8px;border:1px solid #ddd;">Miejsce</th>'
           . '<th style="padding:8px;border:1px solid #ddd;">Imię</th>'
           . '<th style="padding:8px;border:1px solid #ddd;">Nazwisko</th>'
           . '<th style="padding:8px;border:1px solid #ddd;">Szkoła</th>'
           . '<th style="padding:8px;border:1px solid #ddd;">Punkty</th>'
           . '<th style="padding:8px;border:1px solid #ddd;">Ranking</th>'
           . '</tr></thead><tbody>';
    if (empty($wyniki)) {
        $html .= '<tr><td colspan="6" style="text-align:center;padding:20px;">Brak wyników.</td></tr>';
    } else {
        foreach ($wyniki as $w) {
            $html .= '<tr>'
                   . '<td style="padding:8px;border:1px solid #ddd;">' . htmlspecialchars($w['miejsce'],   ENT_QUOTES) . '</td>'
                   . '<td style="padding:8px;border:1px solid #ddd;">' . htmlspecialchars($w['imie'],      ENT_QUOTES) . '</td>'
                   . '<td style="padding:8px;border:1px solid #ddd;">' . htmlspecialchars($w['nazwisko'],  ENT_QUOTES) . '</td>'
                   . '<td style="padding:8px;border:1px solid #ddd;">' . htmlspecialchars($w['szkola'],    ENT_QUOTES) . '</td>'
                   . '<td style="padding:8px;border:1px solid #ddd;">' . htmlspecialchars($w['punkty'],    ENT_QUOTES) . '</td>'
                   . '<td style="padding:8px;border:1px solid #ddd;">' . htmlspecialchars($w['ranking'],   ENT_QUOTES) . '</td>'
                   . '</tr>';
        }
    }
    $html .= '</tbody></table></div>';
    echo json_encode(['html' => $html]);
    exit;
}

// Normalne ładowanie archiwum wyników
$stmt = $pdo->prepare("
  SELECT nazwa, `data`, hash, results_shared_at
  FROM turnieje
  WHERE results_shared = 1
  ORDER BY results_shared_at DESC
");
$stmt->execute();
$pastTourns = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Archiwum wyników | SLS</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/main.css"><!-- Twój główny CSS -->
  <style>
    body { margin:0; font-family:Lato,sans-serif; background:#f0f0f0; color:#131D58; }
    .header__logo-box { position:absolute; top:20px; left:20px; }
    .header__logo     { height:4rem; }
    .section { background:#fff; max-width:1200px; margin:100px auto 60px; padding:40px 20px; border-radius:8px; box-shadow:0 4px 16px rgba(0,0,0,0.1); }
    .section h2 { text-align:center; font-size:2.5rem; margin-bottom:40px; }
    .archive-list { list-style:none; padding:0; margin:0; max-width:800px; margin:0 auto; }
    .archive-list li {
      display:flex; justify-content:space-between; align-items:center;
      background:#fcfcfc; border:1px solid #e0e0e0; border-radius:6px;
      padding:16px 24px; margin-bottom:16px;
      transition:border-color .2s, box-shadow .2s;
    }
    .archive-list li:hover {
      border-color:#131D58; box-shadow:0 2px 8px rgba(19,29,88,0.2);
    }
    .info { display:flex; align-items:center; }
    .name { font-weight:bold; font-size:1.1rem; color:#131D58; }
    .date { margin-left:12px; color:#555; font-size:0.95rem; }
    .badge-new {
      background:#e68a00; color:#fff; padding:4px 10px; margin-left:12px;
      border-radius:4px; font-size:0.8rem;
    }
    .actions button {
      padding:8px 16px; background:#131D58; color:#fff; border:none;
      border-radius:4px; cursor:pointer; transition:background .3s;
    }
    .actions button:hover { background:rgb(16,26,82); }
    @media (max-width:600px) {
      .archive-list li { flex-direction:column; align-items:flex-start; }
      .actions { margin-top:12px; }
    }

    /* Modal */
    .overlay {
      position:fixed; top:0;left:0; width:100%;height:100%;
      background:rgba(0,0,0,0.7); backdrop-filter:blur(5px);
      display:none; align-items:center;justify-content:center; z-index:10000;
    }
    .modal-content {
      background:#fff; padding:20px; border-radius:8px;
      width:90%; max-width:800px; max-height:80%; overflow:auto;
    }
    .close-btn {
      position: absolute;
        top: 10px;
      right: 15px;
      width: 3rem;
      height: 3rem;
      line-height: 3rem;
      font-size: 2rem;
      font-weight: bold;
        color: #fff;
      background: rgba(0,0,0,0.6);
      border-radius: 50%;
      text-align: center;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(0,0,0,0.3);
      transition: background 0.2s;
    }
    .close-btn:hover {
      background: rgba(0,0,0,0.8);
    }

  </style>
</head>
<body>

  <div class="header__logo-box">
    <a href="index.html"><img src="img/logo.avif" alt="Logo SLS" class="header__logo"></a>
  </div>

  <section class="section">
    <h2>Archiwum wyników</h2>
    <?php if (empty($pastTourns)): ?>
      <p style="text-align:center; color:#666;">Brak opublikowanych wyników.</p>
    <?php else: ?>
      <ul class="archive-list">
        <?php foreach ($pastTourns as $t):
          $isNew = (time() - strtotime($t['results_shared_at'])) < 86400;
        ?>
        <li>
          <div class="info">
            <span class="name"><?= htmlspecialchars($t['nazwa'],ENT_QUOTES) ?></span>
            <span class="date">(<?= date('d.m.Y',strtotime($t['data'])) ?>)</span>
            <?php if ($isNew): ?><span class="badge-new">Nowość!</span><?php endif; ?>
          </div>
          <div class="actions">
            <button class="view-btn" data-hash="<?= htmlspecialchars($t['hash'],ENT_QUOTES) ?>">
              Zobacz
            </button>
          </div>
        </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>

  <div id="wynikiModal" class="overlay">
    <div class="modal-content">
      <span class="close-btn">&times;</span>
      <div id="modalBody"></div>
    </div>
  </div>

  <script>
    // Otwarcie modalu i AJAX
    document.querySelectorAll('.view-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const hash = btn.dataset.hash;
        fetch(`wyniki.php?ajax=1&hash=${encodeURIComponent(hash)}`)
          .then(res => res.json())
          .then(data => {
            document.getElementById('modalBody').innerHTML = data.html;
            document.getElementById('wynikiModal').style.display = 'flex';
          });
      });
    });
    // Zamknięcie modalu
    const modal = document.getElementById('wynikiModal');
    modal.querySelector('.close-btn').addEventListener('click', () => {
      modal.style.display = 'none';
    });
    modal.addEventListener('click', e => {
      if (e.target === modal) modal.style.display = 'none';
    });
  </script>

</body>
</html>

