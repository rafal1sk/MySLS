<?php
// sls/login.php
session_start();
require_once __DIR__ . '/../config.php';

// Stałe z nazwą użytkownika i zahashowanym hasłem
define('ADMIN_USER',      'admin');
// Wygeneruj hash jak w opisie i wklej go poniżej:
define('ADMIN_PASS_HASH', '$2y$10$QxpNgo9UcSUq.LpeqSI1sudwGG7jCKe4fEIwboWGwdm3kA.gC4X5m');

// Obsługa POST
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login']   ?? '';
    $haslo = $_POST['haslo']   ?? '';

    // Sprawdzamy login i hasło
    if ($login === ADMIN_USER && password_verify($haslo, ADMIN_PASS_HASH)) {
        // powodzenie
        $_SESSION['admin'] = true;
        header('Location: panel.php');
        exit;
    } else {
        $error = "Nieprawidłowy login lub hasło.";
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Logowanie admina</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      background-color: #98989879;
      font-family: 'League Gothic', sans-serif;
      color: #131D58;
      margin: 0; padding: 20px;
    }
    .header__logo-box {
      position: absolute; top:3%; left:3%;
    }
    .header__logo {
      height: 6rem;
      filter: drop-shadow(0 2rem 4rem rgba(0,0,0,0.9));
      cursor: pointer;
    }
    .container {
      max-width: 400px;
      margin: 120px auto;
      background-color: rgba(134,134,134,0.47);
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(134,134,134,0.47);
    }
    h2 {
      text-align: center; font-size: 2.5rem; margin-bottom: 20px;
    }
    label { display: block; font-weight: bold; margin-top: 15px; }
    input {
      width: 100%; padding: 10px; margin-top: 5px;
      border: none; border-radius: 5px;
      background: rgba(151,151,151,0.47); color: #fff;
    }
    button {
      margin-top: 20px; width: 100%;
      background-color: #131D58; color: #fff;
      border: none; padding: 12px 20px;
      border-radius: 5px; font-weight: bold; cursor: pointer;
      transition: background 0.3s;
    }
    button:hover { background-color: rgb(16,26,82); }
    .error {
      background: #5e2626; color: #ffcece;
      padding: 10px; border-radius: 5px;
      margin-top: 15px; text-align: center;
    }
  </style>
</head>
<body>
  <div class="header__logo-box">
    <a href="panel.php">
      <img src="img/logo.avif" alt="Logo" class="header__logo">
    </a>
  </div>

  <div class="container">
    <h2>Logowanie admina</h2>
    <?php if ($error): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <label for="login">Login:</label>
      <input id="login" name="login" required autofocus>

      <label for="haslo">Hasło:</label>
      <input type="password" id="haslo" name="haslo" required>

      <button type="submit">Zaloguj się</button>
    </form>
  </div>
</body>
</html>
