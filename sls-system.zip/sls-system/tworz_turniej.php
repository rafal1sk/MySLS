<?php
// sls/tworz_turniej.php

// 1) WYŚWIETLAMY BŁĘDY, żeby nie zgubić niczego na HTTP 500:
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2) Ładujemy konfigurację PDO:
require_once __DIR__ . '/config.php';

// 3) (opcjonalnie) blokujemy nie‑adminów:
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$komunikat = "";

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nazwa = trim($_POST['nazwa'] ?? '');
        $data  = $_POST['data']  ?? '';

        if ($nazwa === '' || $data === '') {
            throw new Exception("Uzupełnij wszystkie pola.");
        }

        // 4) Generujemy unikalny hash/token:
        //    8 bajtów -> 16 znaków hex to wystarczająco mocny i krótki łańcuch
        $hash = bin2hex(random_bytes(8));

        // 5) Wstawiamy do bazy również hash:
        $stmt = $pdo->prepare(
            "INSERT INTO turnieje (nazwa, `data`, hash) VALUES (?, ?, ?)"
        );
        $stmt->execute([$nazwa, $data, $hash]);

        // 6) Budujemy pełny adres:
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                    ? 'https' : 'http';
        $host     = $_SERVER['HTTP_HOST'];
        $base     = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
        $link     = "{$protocol}://{$host}{$base}/rejestracja.php?hash={$hash}";

        // 7) Wyświetlamy komunikat z linkiem i przyciskiem kopiowania:
        $komunikat = "
        <div class='success'>
          Turniej <strong>" . htmlspecialchars($nazwa) . "</strong> został utworzony!<br>
          Link do rejestracji:<br>
          <a href='{$link}' target='_blank'>{$link}</a><br><br>
          <button onclick=\"navigator.clipboard.writeText('{$link}');\">
            Kopiuj link
          </button>
        </div>";
    }
} catch (Exception $e) {
    $komunikat = "<div class='error'>" . htmlspecialchars($e->getMessage()) . "</div>";
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Utwórz turniej</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    /* — tutaj wklej swój dotychczasowy CSS bez zmian — */
    body { background-color: #98989879; font-family: 'Lato',sans-serif; color:#131D58; padding:20px; margin:0; }
    .header__logo-box { position:absolute; top:3%; left:3%; }
    .header__logo { filter:drop-shadow(0 2rem 4rem rgba(0,0,0,0.9)); height:6rem; }
    h2 { text-align:center; font-size:3rem; }
    form { max-width:600px; margin:50px auto; background:rgba(134,134,134,0.47); padding:20px; border-radius:8px; box-shadow:0 0 10px rgba(134,134,134,0.47); }
    label { display:block; margin-top:15px; font-weight:bold; }
    input[type="text"], input[type="date"] { width:100%; padding:10px; margin-top:5px; border-radius:5px; border:none; background:rgba(151,151,151,0.47); color:#fff; }
    input::placeholder { color:#000; }
    button { margin-top:20px; background-color:#131D58; color:#fff; border:none; padding:12px 20px; cursor:pointer; border-radius:5px; font-weight:bold; transition:background 0.3s ease; }
    button:hover { background-color:rgb(16,26,82); }
    .success, .error { max-width:600px; margin:20px auto; padding:15px; border-radius:5px; text-align:center; }
    .success { background:#2b572b; color:#aef7ae; }
    .error   { background:#882828; color:#fff; }
    a { color:#fff; font-weight:bold; }
    a:hover { text-decoration:underline; }
  </style>
</head>
<body>

  <div class="header__logo-box">
    <a href="panel.php"><img src="img/logo.avif" alt="Logo" class="header__logo"></a>
  </div>

  <h2>Utwórz nowy turniej</h2>

  <?= $komunikat ?>

  <form method="POST">
    <label for="nazwa">Nazwa turnieju:</label>
    <input type="text" name="nazwa" id="nazwa" required placeholder="Nazwa turnieju">

    <label for="data">Data:</label>
    <input type="date" name="data" id="data" required>

    <button type="submit">Utwórz</button>
  </form>

</body>
</html>


