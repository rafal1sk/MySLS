<?php
// sls/rejestracja_ucznia.php

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
date_default_timezone_set('Europe/Warsaw');

require_once __DIR__ . '/config.php';

$komunikat = '';
$showForm  = false;

// 1) Pobranie i walidacja hash
$hash = $_GET['hash'] ?? '';
if (!$hash) {
    die('<div class="overlay"><div class="modal"><p class="modal-error">Błąd: brak linku rejestracyjnego.</p><p><a href="index.html" class="btn-link">Powrót</a></p></div></div>');
}

// 2) Pobranie danych turnieju wraz z flagą override_registration
$stmt = $pdo->prepare("SELECT id, nazwa, `data`, override_registration FROM turnieje WHERE hash = ?");
$stmt->execute([$hash]);
$turniej = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$turniej) {
    die('<div class="overlay"><div class="modal"><p class="modal-error">Błąd: nie znaleziono turnieju.</p><p><a href="index.html" class="btn-link">Powrót</a></p></div></div>');
}
$turniej_id        = (int)$turniej['id'];
$turniej_date      = $turniej['data'];
$overrideAvailable = (bool)$turniej['override_registration'];

// 3) Obliczenie czasu wygaśnięcia (dzień przed turniejem 23:59)
$startTurnieju = strtotime("$turniej_date 00:00:00");
$expiry        = $startTurnieju - 60;

// 4) Cookie zapobiegające wielokrotnej rejestracji
$cookieName = 'registered_' . $hash;

// 5) Blokady / komunikaty
if (isset($_COOKIE[$cookieName]) && !isset($_GET['registered'])) {
    $komunikat = "
      <div class='overlay'><div class='modal'>
        <p class='modal-error'>Już dokonałeś rejestracji na ten turniej z tego urządzenia.</p>
        <p><a href='index.html' class='btn-link'>Powrót</a></p>
      </div></div>";
}
elseif (time() > $expiry && !$overrideAvailable && !isset($_GET['registered'])) {
    $komunikat = "
      <div class='overlay'><div class='modal'>
        <p class='modal-error'>Rejestracja wygasła dnia " . date('d.m.Y H:i', $expiry) . ".</p>
        <p><a href='index.html' class='btn-link'>Powrót</a></p>
      </div></div>";
}
elseif (isset($_GET['registered'])) {
    $komunikat = "
      <div class='overlay'><div class='modal'>
        <div class='spinner'></div>
        <p>Zgłoszenie przyjęte!<br>Za 10 sekund nastąpi przekierowanie na stronę główną.</p>
        <p><a href='index.html' class='btn-link'>Przejdź teraz</a></p>
      </div></div>
      <script>setTimeout(()=>window.location='index.html',10000);</script>";
}
else {
    $showForm = true;
}

// 6) Obsługa POST
if ($showForm && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $imie            = trim($_POST['imie']      ?? '');
    $nazwisko        = trim($_POST['nazwisko']  ?? '');
    $klasa           = trim($_POST['klasa']     ?? '');
    $email           = trim($_POST['email']     ?? '');
    $szkola_id       = (int)($_POST['szkola_id']   ?? 0);
    $accept_privacy   = isset($_POST['accept_privacy']);
    $accept_regulamin = isset($_POST['accept_regulamin']);

    try {
        // 6a) Kapitalizacja
        $imie     = mb_convert_case(mb_strtolower($imie,     'UTF-8'), MB_CASE_TITLE, 'UTF-8');
        $nazwisko = mb_convert_case(mb_strtolower($nazwisko, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');

        // 6b) Walidacja
        if (!$imie || !$nazwisko || !$klasa || !$email || !$szkola_id) {
            throw new Exception("Uzupełnij wszystkie pola.");
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Podaj poprawny e-mail.");
        }
        if (!$accept_privacy) {
            throw new Exception("Musisz wyrazić zgodę na przetwarzanie danych osobowych.");
        }
        if (!$accept_regulamin) {
            throw new Exception("Musisz zaakceptować regulamin.");
        }

        // 6c) Zapis do bazy
        $ins = $pdo->prepare("
          INSERT INTO uczestnicy
            (imie, nazwisko, klasa, szkola_id, email, zatwierdzony, turniej_id)
          VALUES (?, ?, ?, ?, ?, 0, ?)
        ");
        $ins->execute([
            $imie,
            $nazwisko,
            $klasa,
            $szkola_id,
            $email,
            $turniej_id
        ]);

        // — pobranie nazwy szkoły
        $sp = $pdo->prepare("SELECT nazwa FROM szkoly WHERE id = ?");
        $sp->execute([$szkola_id]);
        $szkola_nazwa = $sp->fetchColumn() ?: '– nieznana –';

        // — identyfikator uczestnika
        $newId = $pdo->lastInsertId();

        // — link do zatwierdzenia
        $confirmLink = "https://{$_SERVER['HTTP_HOST']}/zatwierdz_ucznia.php"
                     . "?hash=" . urlencode($hash)
                     . "&approve=" . $newId;

        // — przygotowanie HTML-maila
        $htmlBodyAdmin = <<<EOD
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Nowa rejestracja – SLS</title></head>
<body style="margin:0;padding:0;font-family:Arial,sans-serif;background:#f4f4f4">
  <table width="600" align="center" cellpadding="0" cellspacing="0" style="background:#fff;margin:30px auto;border-radius:8px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.1);">
    <tr><td style="background:#131D58;padding:20px;text-align:center;">
      <h1 style="margin:0;color:#fff;">Nowa rejestracja</h1>
    </td></tr>
    <tr><td style="padding:20px;color:#333;">
      <p>Pojawiła się nowa rejestracja na <strong>{$turniej['nazwa']}</strong> ({$turniej['data']}).</p>
      <ul>
        <li><strong>Imię i nazwisko:</strong> {$imie} {$nazwisko}</li>
        <li><strong>Klasa:</strong> {$klasa}</li>
        <li><strong>E-mail:</strong> {$email}</li>
        <li><strong>Szkoła:</strong> {$szkola_nazwa}</li>
      </ul>
      <p style="text-align:center;margin:30px 0;">
        <a href="{$confirmLink}" style="background:#131D58;color:#fff;padding:12px 24px;border-radius:4px;text-decoration:none;font-weight:bold;">
          Zatwierdź zgłoszenie
        </a>
      </p>
    </td></tr>
    <tr><td style="background:#f9f9f9;padding:15px;text-align:center;">
      <img src="https://{$_SERVER['HTTP_HOST']}/img/logo.avif" alt="Logo SLS" width="100">
    </td></tr>
  </table>
</body>
</html>
EOD;

        // — nagłówki
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: noreply@{$_SERVER['HTTP_HOST']}\r\n";

        // — wyślij do dwóch adminów
        $to = ADMIN_EMAIL . ',' . ADMIN_EMAIL_CC;
        @mail($to, "Nowa rejestracja – {$turniej['nazwa']}", $htmlBodyAdmin, $headers);

        // PRG
        setcookie($cookieName, '1', $expiry, '/');
        header("Location: ?hash=" . urlencode($hash) . "&registered=1");
        exit;
    } catch (Exception $e) {
        $komunikat = "
          <div class='overlay'><div class='modal'>
            <p class='modal-error'>" . htmlspecialchars($e->getMessage(), ENT_QUOTES) . "</p>
            <p><a href='?hash=" . urlencode($hash) . "' class='btn-link'>Wróć</a></p>
          </div></div>";
        $showForm = false;
    }
}

// 7) Lista szkół
$stmt2 = $pdo->prepare("SELECT id,nazwa FROM szkoly WHERE zatwierdzona=1 ORDER BY nazwa");
$stmt2->execute();
$szkoly = $stmt2->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Rejestracja na turniej</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { margin:0;padding:20px;background:#98989879;font-family:Lato,sans-serif;color:#131D58;}
    .header__logo-box{position:absolute;top:3%;left:3%;}
    .header__logo{height:6rem;filter:drop-shadow(0 2rem 4rem rgba(0,0,0,0.9));cursor:pointer;}
    h2{text-align:center;font-size:3rem;margin-bottom:5px;}
    p.date{text-align:center;margin-bottom:20px;color:#131D58;}
    form{max-width:600px;margin:0 auto;background:rgba(134,134,134,0.47);padding:20px;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.2);}
    label{display:block;margin-top:15px;font-weight:bold;color:#fff;}
    input[type=text],input[type=email],select{width:100%;padding:10px;margin-top:5px;border:none;border-radius:5px;background:rgba(151,151,151,0.47);color:#fff;}
    .checkbox-group{margin-top:15px;color:#fff;}
    .checkbox-group input{transform:scale(1.2);margin-right:8px;vertical-align:middle;}
    button{margin-top:20px;width:100%;padding:12px;background:#131D58;color:#fff;border:none;border-radius:5px;font-weight:bold;cursor:pointer;transition:background .3s;}
    button:hover{background:rgb(16,26,82);}
    .regulamin{max-width:600px;margin:30px auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 0 8px rgba(0,0,0,0.1);color:#000;line-height:1.4;}
    .regulamin h3{margin-top:0;} .regulamin ol{padding-left:20px;}
    .overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);backdrop-filter:blur(5px);display:flex;align-items:center;justify-content:center;z-index:10000;}
    .overlay .modal{text-align:center;color:#fff;padding:20px;} .modal-error{color:#ffcece;font-weight:bold;}
    .spinner{margin:10px auto 20px;width:40px;height:40px;border:4px solid #f3f3f3;border-top:4px solid #131D58;border-radius:50%;animation:spin 1s linear infinite;}
    @keyframes spin{to{transform:rotate(360deg);}}
    .btn-link{display:inline-block;margin-top:15px;padding:10px 20px;background:#fff;color:#131D58;border-radius:5px;text-decoration:none;font-weight:bold;transition:background .3s;}
    .btn-link:hover{background:#f1f1f1;}
  </style>
</head>
<body>

<div class="header__logo-box">
  <a href="index.html"><img src="img/logo.avif" alt="Logo" class="header__logo"></a>
</div>

<h2>Rejestracja na turniej</h2>
<?php if ($turniej): ?>
  <p class="date"><?= htmlspecialchars($turniej['nazwa'],ENT_QUOTES) ?> – <?= date('d.m.Y',strtotime($turniej['data'])) ?></p>
<?php endif; ?>

<?= $komunikat ?>

<?php if ($showForm): ?>
<form method="POST" action="?hash=<?= urlencode($hash) ?>">
  <label for="imie">Imię:</label>
  <input type="text" id="imie" name="imie" required placeholder="Jan">

  <label for="nazwisko">Nazwisko:</label>
  <input type="text" id="nazwisko" name="nazwisko" required placeholder="Kowalski">

  <label for="klasa">Klasa:</label>
  <input type="text" id="klasa" name="klasa" required placeholder="np. 3a">

  <label for="email">E-mail:</label>
  <input type="email" id="email" name="email" required placeholder="adres@szkola.pl">

  <label for="szkola_id">Szkoła:</label>
  <select id="szkola_id" name="szkola_id" required>
    <option value="">– wybierz szkołę –</option>
    <?php foreach ($szkoly as $s): ?>
      <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['nazwa'],ENT_QUOTES) ?></option>
    <?php endforeach; ?>
  </select>

  <div class="checkbox-group">
    <input type="checkbox" id="accept_privacy" name="accept_privacy" required>
    <label for="accept_privacy">Wyrażam zgodę na przetwarzanie danych osobowych.</label>
  </div>

  <div class="checkbox-group">
    <input type="checkbox" id="accept_regulamin" name="accept_regulamin" required>
    <label for="accept_regulamin">Akceptuję Regulamin Szachowej Ligi Szkolnej.</label>
  </div>

  <button type="submit">Zarejestruj się</button>
</form>
<?php endif; ?>

<div class="regulamin">
  <h3>Regulamin Szachowej Ligi Szkolnej</h3>
  <ol>
    <li>Uczestnictwo tylko dla uczniów zatwierdzonych szkół.</li>
    <li>Rejestracja wymaga podania prawdziwych danych.</li>
    <li>Partie rozgrywane według przepisów FIDE.</li>
    <li>Prawo do zmian terminów zastrzeżone.</li>
    <li>Dane przetwarzane wyłącznie w celu organizacji rozgrywek.</li>
  </ol>
</div>

</body>
</html>















