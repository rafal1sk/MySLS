<?php
$host = "mysql8"; 
$dbname = "39368714_liga"; 
$username = "39368714_liga"; 
$password = "Sl2015!!!";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Błąd połączenia z bazą danych: " . $e->getMessage());
}



function fetchAllFromTable($pdo, $tableName) {
    $stmt = $pdo->prepare("SELECT * FROM $tableName");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function debug($data) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}
define('ADMIN_EMAIL', 'bartoszmichalek.pl@gmail.com'); 
define('ADMIN_EMAIL_CC', 'franek.tatara2007@gmail.com');
?>

