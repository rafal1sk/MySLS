<?php
// sls/zatwierdz_ucznia.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/config.php';

// 1) Pobranie i walidacja hash
$hash = $_GET['hash'] ?? '';
if (!$hash) {
    die('<div class="error">Brak parametru turnieju!</div>');
}

// 2) Pobranie danych turnieju
$stmt = $pdo->prepare("SELECT id, nazwa, `data` FROM turnieje WHERE hash = ?");
$stmt->execute([$hash]);
$turniej = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$turniej) {
    die('<div class="error">Nie znaleziono turnieju!</div>');
}
$turniej_id = (int)$turniej['id'];

$msg = '';

// 3) Obsługa zatwierdzania
if (isset($_GET['approve'])) {
    $uid = (int)$_GET['approve'];
    // pobierz dane ucznia
    $pu = $pdo->prepare("SELECT imie, nazwisko, email FROM uczestnicy WHERE id = ? AND turniej_id = ?");
    $pu->execute([$uid, $turniej_id]);
    $p = $pu->fetch(PDO::FETCH_ASSOC);

    if ($p) {
        $upd = $pdo->prepare("UPDATE uczestnicy SET zatwierdzony = 1 WHERE id = ? AND turniej_id = ?");
        $upd->execute([$uid, $turniej_id]);
        if ($upd->rowCount()) {
            // Wyślij HTML-mail do ucznia
            $to      = $p['email'];
            $subject = "Zatwierdzenie zgłoszenia – {$turniej['nazwa']}";
            $link    = "https://{$_SERVER['HTTP_HOST']}/wyniki_podglad.php?hash=" . urlencode($hash);

            $htmlBody = <<<EOD
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Potwierdzenie zgłoszenia – Szachowa Liga Szkolna</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,sans-serif;">
  <table align="center" width="600" cellpadding="0" cellspacing="0" style="background:#fff;margin:30px auto;border-radius:8px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.1);">
    <tr>
      <td style="background:#131D58;padding:20px;text-align:center;">
        <h1 style="margin:0;font-size:24px;color:#fff;">Potwierdzenie zgłoszenia</h1>
      </td>
    </tr>
    <tr>
      <td style="padding:30px;color:#333;font-size:16px;line-height:1.5;">
        <p>Cześć <strong>{$p['imie']} {$p['nazwisko']}</strong>,</p>
        <p>Twoje zgłoszenie na turniej <strong>{$turniej['nazwa']}</strong> w dniu <strong>{$turniej['data']}</strong> zostało zatwierdzone.</p>
        <p style="text-align:center;">
          <a href="https://szachowaligaszkolna.pl/wyniki.php" style="display:inline-block;background:#131D58;color:#fff;text-decoration:none;padding:12px 24px;border-radius:4px;font-weight:bold;">
            Zobacz swoje wyniki
          </a>
        </p>
        <p>Życzymy powodzenia i wielu sukcesów przy szachownicy!</p>
        <p>Pozdrawiamy,<br><em>Zespół Szachowej Ligi Szkolnej</em></p>
      </td>
    </tr>
    <tr>
      <td style="background:#f9f9f9;padding:20px;text-align:center;">
        <img src="https://{$_SERVER['HTTP_HOST']}/img/logo.avif" alt="Logo SLS" width="120" style="display:block;margin:0 auto;">
      </td>
    </tr>
  </table>
</body>
</html>
EOD;

            $headers  = "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $headers .= "From: noreply@{$_SERVER['HTTP_HOST']}\r\n";

            @mail($to, $subject, $htmlBody, $headers);

            $msg = "<div class='success'>Zatwierdzono ucznia i wysłano maila.</div>";
        } else {
            $msg = "<div class='error'>Błąd zapisu podczas zatwierdzania.</div>";
        }
    } else {
        $msg = "<div class='error'>Nie znaleziono zgłoszenia.</div>";
    }
}

// 4) Obsługa usuwania
if (isset($_GET['delete'])) {
    $uid = (int)$_GET['delete'];
    $del = $pdo->prepare("DELETE FROM uczestnicy WHERE id = ? AND turniej_id = ?");
    if ($del->execute([$uid, $turniej_id])) {
        $msg = "<div class='success'>Usunięto zgłoszenie ucznia.</div>";
    } else {
        $msg = "<div class='error'>Nie udało się usunąć zgłoszenia.</div>";
    }
}

// 5) Pobranie listy oczekujących zgłoszeń
$stmt2 = $pdo->prepare("
    SELECT
      u.id,
      u.imie,
      u.nazwisko,
      u.email,
      s.nazwa AS szkola,
      u.klasa
    FROM uczestnicy u
    JOIN szkoly s ON s.id = u.szkola_id
    WHERE u.turniej_id = ? AND u.zatwierdzony = 0
    ORDER BY u.id ASC
");
$stmt2->execute([$turniej_id]);
$uczestnicy = $stmt2->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Zatwierdź uczniów – <?= htmlspecialchars($turniej['nazwa'], ENT_QUOTES) ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { background:#98989879; font-family:'Lato',sans-serif; color:#131D58; margin:0; padding:20px; }
    .header__logo-box { position:absolute; top:3%; left:3%; }
    .header__logo { height:6rem; filter:drop-shadow(0 2rem 4rem rgba(0,0,0,0.9)); cursor:pointer; }
    .container { max-width:900px; margin:100px auto; background:rgba(134,134,134,0.47); padding:30px; border-radius:8px; box-shadow:0 0 10px rgba(134,134,134,0.47); }
    h2 { text-align:center; font-size:2.8rem; margin-bottom:5px; }
    p.date { text-align:center; margin-bottom:20px; }
    .success, .error { max-width:800px; margin:10px auto; padding:12px; border-radius:5px; text-align:center; }
    .success { background:#2b572b; color:#aef7ae; }
    .error   { background:#882828; color:#fff; }
    table { width:100%; border-collapse:collapse; border-radius:5px; overflow:hidden; background:#fff; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
    thead { background:#131D58; }
    thead th { color:#fff; padding:12px; text-align:left; font-weight:normal; font-size:0.9rem; }
    tbody tr:nth-child(even) { background:#f4f4f4; }
    tbody tr:hover { background:#e0e0e0; }
    tbody td { padding:10px; font-size:0.9rem; vertical-align:middle; }
    a.btn, button.btn { display:inline-block; padding:6px 14px; background:#131D58; color:#fff; text-decoration:none; border:none; border-radius:4px; margin:4px; cursor:pointer; transition:background .3s; font-size:0.9rem; }
    a.btn:hover, button.btn:hover { background:rgb(16,26,82); }
    .btn-delete { background:#a00; }
    .btn-delete:hover { background:#800; }
    .back-btn { display:block; text-align:center; margin-top:20px; }
  </style>
</head>
<body>

  <div class="header__logo-box">
    <a href="panel.php"><img src="img/logo.avif" alt="Logo" class="header__logo"></a>
  </div>

  <div class="container">
    <h2>Zatwierdź uczniów</h2>
    <p class="date"><?= date('d.m.Y', strtotime($turniej['data'])) ?></p>

    <?= $msg ?>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Imię</th>
          <th>Nazwisko</th>
          <th>E-mail</th>
          <th>Szkoła</th>
          <th>Klasa</th>
          <th>Akcje</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($uczestnicy)): ?>
          <tr><td colspan="7" style="text-align:center; padding:20px;">Brak zgłoszeń do zatwierdzenia.</td></tr>
        <?php else: foreach ($uczestnicy as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['imie'],     ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($u['nazwisko'], ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($u['email'],    ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($u['szkola'],   ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($u['klasa'],    ENT_QUOTES) ?></td>
            <td>
              <a href="?hash=<?= urlencode($hash) ?>&approve=<?= $u['id'] ?>"
                 class="btn"
                 onclick="return confirm('Zatwierdzić zgłoszenie #<?= $u['id'] ?>?');">
                Zatwierdź
              </a>
              <button class="btn btn-delete"
                      onclick="if(confirm('Usunąć zgłoszenie #<?= $u['id'] ?>?')) window.location='?hash=<?= urlencode($hash) ?>&delete=<?= $u['id'] ?>';">
                Usuń
              </button>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>

    <div class="back-btn">
      <a href="panel_turnieju.php?hash=<?= urlencode($hash) ?>" class="btn">← Powrót do panelu</a>
    </div>
  </div>

</body>
</html>





