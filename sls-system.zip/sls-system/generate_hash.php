<?php

$password = 'Sl2015!!!';


$hashedPassword = password_hash($password, PASSWORD_DEFAULT);


echo 'Zahaszowane hasło: ' . $hashedPassword;
?>
