<?php
require 'config.php';

$sql = "SELECT * FROM events ORDER BY event_date DESC LIMIT 4";
$stmt = $pdo->query($sql);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($events as $event) {
    echo "<div class='event'>";
    echo "<img src='" . htmlspecialchars($event["image"]) . "' alt='Obraz wydarzenia'>";
    echo "<h3>" . htmlspecialchars($event["title"]) . "</h3>";
    echo "<p><strong>Data:</strong> " . htmlspecialchars($event["event_date"]) . "</p>";
    echo "<p>" . nl2br(htmlspecialchars($event["description"])) . "</p>";
    echo "</div>";
}
?>

